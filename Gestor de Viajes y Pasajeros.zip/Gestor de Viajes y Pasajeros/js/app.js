// Clase para manejar los viajes
class Viaje {
    constructor(destino, fecha, duracion, precio, nombrePasajero, dniPasajero) {
        this.id = Date.now();
        this.destino = destino;
        this.fecha = fecha;
        this.duracion = duracion;
        this.precio = precio;
        this.nombrePasajero = nombrePasajero;
        this.dniPasajero = dniPasajero;
        this.importeTotal = this.calcularImporteTotal();
    }

    calcularImporteTotal() {
        return this.precio * this.duracion;
    }
}

// Clase para manejar el almacenamiento
class Almacenamiento {
    static guardarViaje(viaje) {
        const viajes = this.obtenerViajes();
        viajes.push(viaje);
        localStorage.setItem('viajes', JSON.stringify(viajes));
        this.mostrarNotificacion('Viaje registrado exitosamente', 'success');
    }

    static obtenerViajes() {
        const viajes = localStorage.getItem('viajes');
        return viajes ? JSON.parse(viajes) : [];
    }

    static eliminarViaje(id) {
        let viajes = this.obtenerViajes();
        viajes = viajes.filter(viaje => viaje.id !== id);
        localStorage.setItem('viajes', JSON.stringify(viajes));
        this.mostrarNotificacion('Viaje eliminado exitosamente', 'danger');
    }

    static actualizarViaje(viajeActualizado) {
        let viajes = this.obtenerViajes();
        viajes = viajes.map(viaje => 
            viaje.id === viajeActualizado.id ? viajeActualizado : viaje
        );
        localStorage.setItem('viajes', JSON.stringify(viajes));
        this.mostrarNotificacion('Viaje actualizado exitosamente', 'success');
    }

    static mostrarNotificacion(mensaje, tipo) {
        const notificacion = document.createElement('div');
        notificacion.className = `alert alert-${tipo} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        notificacion.style.zIndex = '1050';
        notificacion.innerHTML = `
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(notificacion);
        setTimeout(() => notificacion.remove(), 3000);
    }
}

// Clase para manejar la interfaz de usuario
class UI {
    static mostrarViajes(viajes) {
        const listaViajes = document.getElementById('listaViajes');
        listaViajes.innerHTML = '';

        if (viajes.length === 0) {
            listaViajes.innerHTML = `
                <tr>
                    <td colspan="9" class="text-center py-4">
                        <i class="fas fa-info-circle"></i> No hay viajes registrados
                    </td>
                </tr>
            `;
            return;
        }

        viajes.forEach(viaje => {
            const tr = document.createElement('tr');
            const diasHastaViaje = this.calcularDiasHastaViaje(viaje.fecha);
            
            // Aplicar clase según la proximidad del viaje
            if (diasHastaViaje < 15) {
                tr.classList.add('viaje-proximo');
            } else if (diasHastaViaje < 30) {
                tr.classList.add('viaje-medio');
            } else {
                tr.classList.add('viaje-lejano');
            }

            tr.innerHTML = `
                <td>${viaje.destino}</td>
                <td>${new Date(viaje.fecha).toLocaleDateString()}</td>
                <td>${viaje.duracion}</td>
                <td>$${viaje.precio.toLocaleString()}</td>
                <td>${viaje.nombrePasajero}</td>
                <td>${viaje.dniPasajero}</td>
                <td>$${viaje.importeTotal.toLocaleString()}</td>
                <td>
                    <span class="badge ${this.getBadgeClass(diasHastaViaje)}">
                        ${this.getDiasText(diasHastaViaje)}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-warning btn-action" onclick="UI.editarViaje(${viaje.id})" title="Editar">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger btn-action" onclick="UI.eliminarViaje(${viaje.id})" title="Eliminar">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            listaViajes.appendChild(tr);
        });
    }

    static calcularDiasHastaViaje(fecha) {
        const hoy = new Date();
        const fechaViaje = new Date(fecha);
        const diferencia = fechaViaje - hoy;
        return Math.ceil(diferencia / (1000 * 60 * 60 * 24));
    }

    static mostrarEstadisticas() {
        const viajes = Almacenamiento.obtenerViajes();
        
        // Estadísticas por destino
        const estadisticasDestino = {};
        viajes.forEach(viaje => {
            if (!estadisticasDestino[viaje.destino]) {
                estadisticasDestino[viaje.destino] = 0;
            }
            estadisticasDestino[viaje.destino] += viaje.importeTotal;
        });

        // Estadísticas por viaje
        const estadisticasPasajeros = {};
        viajes.forEach(viaje => {
            const key = `${viaje.destino} - ${new Date(viaje.fecha).toLocaleDateString()}`;
            if (!estadisticasPasajeros[key]) {
                estadisticasPasajeros[key] = 0;
            }
            estadisticasPasajeros[key]++;
        });

        // Mostrar estadísticas
        const contenedorDestino = document.getElementById('estadisticasDestino');
        const contenedorPasajeros = document.getElementById('estadisticasPasajeros');

        if (Object.keys(estadisticasDestino).length === 0) {
            contenedorDestino.innerHTML = '<p class="text-center">No hay datos disponibles</p>';
        } else {
            contenedorDestino.innerHTML = Object.entries(estadisticasDestino)
                .map(([destino, total]) => `
                    <p class="d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-map-marker-alt"></i> ${destino}</span>
                        <span class="badge bg-primary">$${total.toLocaleString()}</span>
                    </p>
                `)
                .join('');
        }

        if (Object.keys(estadisticasPasajeros).length === 0) {
            contenedorPasajeros.innerHTML = '<p class="text-center">No hay datos disponibles</p>';
        } else {
            contenedorPasajeros.innerHTML = Object.entries(estadisticasPasajeros)
                .map(([viaje, cantidad]) => `
                    <p class="d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-plane"></i> ${viaje}</span>
                        <span class="badge bg-success">${cantidad} pasajeros</span>
                    </p>
                `)
                .join('');
        }
    }

    static limpiarFormulario() {
        document.getElementById('viajeForm').reset();
        document.getElementById('importeTotal').value = '';
        const submitBtn = document.querySelector('#viajeForm button[type="submit"]');
        submitBtn.textContent = 'Registrar Viaje';
        delete submitBtn.dataset.editId;
    }

    static editarViaje(id) {
        const viajes = Almacenamiento.obtenerViajes();
        const viaje = viajes.find(v => v.id === id);
        
        if (viaje) {
            document.getElementById('destino').value = viaje.destino;
            document.getElementById('fecha').value = viaje.fecha;
            document.getElementById('duracion').value = viaje.duracion;
            document.getElementById('precio').value = viaje.precio;
            document.getElementById('nombrePasajero').value = viaje.nombrePasajero;
            document.getElementById('dniPasajero').value = viaje.dniPasajero;
            
            // Cambiar el botón de submit
            const submitBtn = document.querySelector('#viajeForm button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-save"></i> Actualizar Viaje';
            submitBtn.dataset.editId = id;

            // Scroll al formulario
            document.getElementById('registro').scrollIntoView({ behavior: 'smooth' });
        }
    }

    static eliminarViaje(id) {
        if (confirm('¿Está seguro de que desea eliminar este viaje?')) {
            Almacenamiento.eliminarViaje(id);
            this.actualizarVista();
        }
    }

    static actualizarVista() {
        const viajes = Almacenamiento.obtenerViajes();
        this.mostrarViajes(viajes);
        this.mostrarEstadisticas();
    }

    static getBadgeClass(diasHastaViaje) {
        if (diasHastaViaje < 15) {
            return 'bg-success';
        } else if (diasHastaViaje < 30) {
            return 'bg-warning';
        } else {
            return 'bg-danger';
        }
    }

    static getDiasText(diasHastaViaje) {
        if (diasHastaViaje < 15) {
            return 'Próximo';
        } else if (diasHastaViaje < 30) {
            return 'Medio';
        } else {
            return 'Lejano';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Inicializar la vista
    UI.actualizarVista();

    // Inicializar estado del botón de limpiar filtros
    document.getElementById('btnLimpiarFiltros').disabled = true;

    // Calcular importe total automáticamente
    const calcularImporte = () => {
        const duracion = document.getElementById('duracion').value;
        const precio = document.getElementById('precio').value;
        const importeTotal = document.getElementById('importeTotal');
        
        if (duracion && precio) {
            const total = duracion * precio;
            importeTotal.value = `$${total.toLocaleString()}`;
        }
    };

    document.getElementById('duracion').addEventListener('input', calcularImporte);
    document.getElementById('precio').addEventListener('input', calcularImporte);

    // Manejar el formulario
    document.getElementById('viajeForm').addEventListener('submit', (e) => {
        e.preventDefault();

        const submitBtn = e.target.querySelector('button[type="submit"]');
        const editId = submitBtn.dataset.editId;

        const viaje = new Viaje(
            document.getElementById('destino').value,
            document.getElementById('fecha').value,
            parseInt(document.getElementById('duracion').value),
            parseFloat(document.getElementById('precio').value),
            document.getElementById('nombrePasajero').value,
            document.getElementById('dniPasajero').value
        );

        if (editId) {
            viaje.id = parseInt(editId);
            Almacenamiento.actualizarViaje(viaje);
        } else {
            Almacenamiento.guardarViaje(viaje);
        }

        UI.limpiarFormulario();
        UI.actualizarVista();
    });

    // Manejar filtros
    document.getElementById('filtroDestino').addEventListener('input', filtrarViajes);
    document.getElementById('filtroPasajero').addEventListener('input', filtrarViajes);

    // Manejar botón de limpiar filtros
    document.getElementById('btnLimpiarFiltros').addEventListener('click', limpiarFiltros);

    // Navegación suave
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            document.querySelector(targetId).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});

// Función para filtrar viajes
function filtrarViajes() {
    const filtroDestino = document.getElementById('filtroDestino').value.toLowerCase();
    const filtroPasajero = document.getElementById('filtroPasajero').value.toLowerCase();
    const btnLimpiar = document.getElementById('btnLimpiarFiltros');
    
    const viajes = Almacenamiento.obtenerViajes();
    const viajesFiltrados = viajes.filter(viaje => 
        viaje.destino.toLowerCase().includes(filtroDestino) &&
        viaje.nombrePasajero.toLowerCase().includes(filtroPasajero)
    );

    // Habilitar/deshabilitar botón de limpiar filtros
    const hayFiltros = filtroDestino || filtroPasajero;
    btnLimpiar.disabled = !hayFiltros;

    // Mostrar contador de resultados
    mostrarContadorResultados(viajesFiltrados.length, viajes.length);
    
    UI.mostrarViajes(viajesFiltrados);
}

// Función para mostrar contador de resultados
function mostrarContadorResultados(resultados, total) {
    const contadorElement = document.getElementById('contadorResultados');
    if (!contadorElement) {
        // Crear elemento si no existe
        const filtrosSection = document.getElementById('filtros');
        const cardBody = filtrosSection.querySelector('.card-body');
        const contador = document.createElement('div');
        contador.id = 'contadorResultados';
        contador.className = 'mt-3 p-2 rounded';
        cardBody.appendChild(contador);
    }
    
    const contador = document.getElementById('contadorResultados');
    if (resultados === total) {
        contador.innerHTML = `<i class="fas fa-info-circle text-info"></i> Mostrando todos los viajes (${total})`;
        contador.className = 'mt-3 p-2 rounded bg-info bg-opacity-10';
    } else {
        contador.innerHTML = `<i class="fas fa-filter text-warning"></i> Mostrando ${resultados} de ${total} viajes`;
        contador.className = 'mt-3 p-2 rounded bg-warning bg-opacity-10';
    }
}

// Función para limpiar filtros
function limpiarFiltros() {
    document.getElementById('filtroDestino').value = '';
    document.getElementById('filtroPasajero').value = '';
    document.getElementById('btnLimpiarFiltros').disabled = true;
    filtrarViajes();
} 